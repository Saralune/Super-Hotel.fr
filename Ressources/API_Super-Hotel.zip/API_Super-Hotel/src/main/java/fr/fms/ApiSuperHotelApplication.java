package fr.fms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiSuperHotelApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiSuperHotelApplication.class, args);
	}

}
