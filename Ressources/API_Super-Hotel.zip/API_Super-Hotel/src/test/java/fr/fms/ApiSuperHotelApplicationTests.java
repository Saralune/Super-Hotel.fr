package fr.fms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiSuperHotelApplicationTests {

	@Test
	void contextLoads() {
	}

}
